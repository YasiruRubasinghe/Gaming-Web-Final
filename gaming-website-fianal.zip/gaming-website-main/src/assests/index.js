const logoICN = require('./logo.png');
const A1IMG = require('./A1.jpg');
const A2IMG = require('./A2.jpg');
const A3IMG = require('./A3.jpg');
const NOTFOUND_IMG = require('./notfound.jpg');

export const ICONS = {
    logoICN
}

export const IMAGES = {
    A1IMG,
    A2IMG,
    A3IMG,
    NOTFOUND_IMG
}