export const baseUrl="http://localhost:8080/api/v1"

export const loginUrl="/user/login";

export const saveGameUrl="/game/save";
export const updateGameUrl="/game/update";
export const deleteGameUrl="/game/delete/"; //{id}
export const getAllGameUrl="/game/get-all";
