
import './App.css';
import RootRouter from './router/RootRouter';

function App() {
  return (
    <RootRouter/>
  );
}

export default App;
